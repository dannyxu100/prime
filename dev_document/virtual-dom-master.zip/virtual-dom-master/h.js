var h = require("./virtual-hyperscript/index.js")

module.exports = h
